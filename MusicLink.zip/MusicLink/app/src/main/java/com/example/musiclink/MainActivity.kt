package com.example.musiclink

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var nowPlaying: TextView
    private lateinit var listBox: LinearLayout
    private val ticker = object : Runnable {
        override fun run() { refreshNowPlaying(); h.postDelayed(this, 1500) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        root.addView(TextView(this).apply { text = "MusicLink"; textSize = 28f })
        nowPlaying = TextView(this).apply { text = "Kuch play nahi ho raha"; textSize = 16f; setPadding(0, 16, 0, 16) }
        root.addView(nowPlaying)

        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun btn(t: String, f: (MediaController) -> Unit) = Button(this).apply {
            text = t; setOnClickListener { activeController()?.let(f) ?: toast("Pehle 'Allow controls' dabao aur kuch play karo") }
        }
        controls.addView(btn("⏮") { it.transportControls.skipToPrevious() })
        controls.addView(btn("⏯") { c ->
            if (c.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play()
        })
        controls.addView(btn("⏭") { it.transportControls.skipToNext() })
        root.addView(controls)

        root.addView(Button(this).apply {
            text = "Allow controls (notification access)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })

        root.addView(TextView(this).apply { text = "Playlist add karo"; textSize = 18f; setPadding(0, 32, 0, 8) })
        val name = EditText(this).apply { hint = "Naam (e.g. Gym mix)" }
        val link = EditText(this).apply { hint = "Spotify ya YT Music playlist link" }
        root.addView(name); root.addView(link)
        root.addView(Button(this).apply {
            text = "Add"
            setOnClickListener {
                val n = name.text.toString().trim(); val l = link.text.toString().trim()
                if (n.isEmpty() || !(l.contains("spotify") || l.contains("youtube"))) { toast("Naam aur valid link daalo"); return@setOnClickListener }
                val arr = load(); arr.put(JSONObject().put("n", n).put("l", l)); save(arr)
                name.text.clear(); link.text.clear(); render()
            }
        })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    override fun onResume() { super.onResume(); h.post(ticker) }
    override fun onPause() { super.onPause(); h.removeCallbacks(ticker) }

    private fun prefs() = getSharedPreferences("p", Context.MODE_PRIVATE)
    private fun load() = JSONArray(prefs().getString("list", "[]"))
    private fun save(a: JSONArray) = prefs().edit().putString("list", a.toString()).apply()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun render() {
        listBox.removeAllViews()
        val arr = load()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val isSp = o.getString("l").contains("spotify")
            listBox.addView(Button(this).apply {
                text = (if (isSp) "🟢 " else "🔴 ") + o.getString("n") + "  ▶"
                isAllCaps = false
                setOnClickListener { play(o.getString("l")) }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setMessage("Delete '${o.getString("n")}'?")
                        .setPositiveButton("Delete") { _, _ ->
                            val na = JSONArray(); for (j in 0 until arr.length()) if (j != i) na.put(arr.get(j)); save(na); render()
                        }.setNegativeButton("Cancel", null).show(); true
                }
            })
        }
        if (arr.length() == 0) listBox.addView(TextView(this).apply { text = "Abhi koi playlist nahi. Upar add karo. (Delete: long press)" })
    }

    private fun play(link: String) {
        val isSp = link.contains("spotify")
        val uri: String; val pkg: String
        if (isSp) {
            val m = Regex("(playlist|album|artist)[/:]([A-Za-z0-9]+)").find(link)
            uri = if (link.startsWith("spotify:")) link else if (m != null) "spotify:${m.groupValues[1]}:${m.groupValues[2]}" else link
            pkg = "com.spotify.music"
        } else { uri = link; pkg = "com.google.android.apps.youtube.music" }
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(Intent(i).setPackage(pkg)) }
        catch (e: Exception) {
            try { startActivity(i) } catch (e2: Exception) { toast("App nahi mila: install karo"); return }
        }
        // Nudge play after the app opens the playlist
        h.postDelayed({ activeController()?.transportControls?.play() }, 3000)
    }

    private fun listenerEnabled(): Boolean =
        (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)

    private fun activeController(): MediaController? {
        if (!listenerEnabled()) return null
        return try {
            val l = getSystemService(MediaSessionManager::class.java)
                .getActiveSessions(ComponentName(this, MediaListener::class.java))
            l.firstOrNull { it.packageName == "com.spotify.music" || it.packageName == "com.google.android.apps.youtube.music" } ?: l.firstOrNull()
        } catch (e: SecurityException) { null }
    }

    private fun refreshNowPlaying() {
        val c = activeController()
        val md = c?.metadata
        nowPlaying.text = if (md == null) (if (listenerEnabled()) "Kuch play nahi ho raha" else "Controls ke liye access allow karo")
        else "🎵 ${md.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "?"}\n${md.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: ""}"
    }
}
