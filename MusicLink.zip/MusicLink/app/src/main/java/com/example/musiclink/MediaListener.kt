package com.example.musiclink

import android.service.notification.NotificationListenerService

// Empty on purpose: having this enabled gives MusicLink permission to control
// the active media session (Spotify / YT Music) via MediaSessionManager.
class MediaListener : NotificationListenerService()
